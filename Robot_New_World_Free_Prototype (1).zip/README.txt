ROBOT: NEW WORLD — FREE PLAYABLE PROTOTYPE

This is a zero-cost browser prototype designed as the foundation for the larger game.

RUN:
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, or Firefox.
3. No installation, account, paid plan, or server is required for this prototype.
4. Controls: WASD / arrow keys to move, Shift to sprint, E to interact, R to repair, 1-5 to change job.

CURRENT SYSTEMS:
- Futuristic Earth-like city layout
- 12 functional city districts
- 150 robot NPCs with different occupations
- Vehicles and roads
- Player robot
- Robot roles: Explorer, Engineer, Medic, Builder, Transit
- Digital credits and transactions
- Daily income
- Health and energy
- Basic collision/physics-inspired movement
- Day/night clock progression
- Interactions with hospitals, schools, research, factories, farms, market, transit, construction, spaceport, etc.
- Expandable single-file architecture

IMPORTANT:
This is the first playable foundation, not the final photorealistic AAA version. The project is deliberately simple so it runs without a paid engine or asset subscription and can be expanded day by day.

NEXT DEVELOPMENT TARGETS:
1. Replace 2D rendering with full 3D.
2. Add Blender-created original robot models.
3. Add skeletal animation and job-specific animations.
4. Add stronger physics, vehicles, weather, buildings and interiors.
5. Expand the digital economy into production, jobs, inventory, buying/selling and supply chains.
6. Add story, missions, exploration and the larger Galaxy/space stage.
